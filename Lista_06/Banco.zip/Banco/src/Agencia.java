public class Agencia {

    private String nome_Banco = "JavaBank";
    private double taxa_Saque = 5.0;
    private static int total_Contas_Abertas;


    public String getNomeBanco()
    {

        return nome_Banco;

    }

    public double getTaxaSaque()
    {

        return taxa_Saque;

    }

    public int total_Contas_Abertas()
    {

        return total_Contas_Abertas;

    }


    public static void registrarContaNova() { total_Contas_Abertas++; }

}
