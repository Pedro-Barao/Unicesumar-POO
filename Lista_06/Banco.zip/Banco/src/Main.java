import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args)
    {

        Scanner scanner = new Scanner(System.in);
        
        String CPF = "a", nome = "a", email = "a", numero_Conta = "a";
        int resposta = 0, resposta_final = 0;
        double saldo = 0.0;
        boolean produto_existe = false;

        Cliente cliente = new Cliente(CPF, nome, email);

        ContaBancaria conta = new ContaBancaria(numero_Conta, cliente, saldo);

        Map<String, Cliente> cliente_conta = new HashMap<>();

        System.out.println("\nOlá! seja bem-vindo(a) ao sistema de criação de contas bancárias");

        do
        {

            System.out.print("\n\nO que deseja executar?:\n\n1) Cadastrar uma novo Cliente\n2) Cadastrar uma nova Conta\n3) Depositar\n3) Sacar\n5) Consultar Quantas contas abertas\n6) Sair do sistema\n=R:");

            resposta = scanner.nextInt();

            scanner.nextLine();

            switch(resposta)
            {

                case 1:

                    System.out.println("\nQual o CPF do Cliente?: ");
                    CPF = scanner.nextLine();

                    System.out.println("\nQual o nome do Cliente?: ");
                    nome = scanner.nextLine();

                    System.out.println("\nQual o email do Cliente");
                    email = scanner.nextLine();
                    
                    cliente(CPF, nome, email);

                    break;

                case 2:

                    System.out.println("\nQual o SKU do produto existente?: ");
                    CPF = scanner.nextLine();

                    produto_existe = produto.darBaixa(CPF);

                    if(produto_existe)
                    {

                        System.out.println("\nProduto deletado com sucesso");

                    }

                    else
                    {

                        System.out.println("\nProduto não existente ou não deletado");

                    }

                    break;

                case 3:

                    System.out.println("\nQual o SKU do novo produto?: ");
                    CPF = scanner.nextLine();

                    produto.consultarQuantidade(CPF);

                    break;

                case 4:

                    produto.consultarProduto();

                    break;

                case 6:

                    System.out.println("\nPretende mesmo sair do sistema?(1 - Sim | 2 - Não): ");
                    
                    resposta_final = scanner.nextInt();

                    break;

                default:

                    System.out.println("\n\nInsira um valor válido para gerar resposta");

                    break;

            }

        } while(resposta_final != 1);

        scanner.close();

    }

}
