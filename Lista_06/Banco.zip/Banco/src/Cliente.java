public class Cliente {
    
    private String CPF;
    private String nome;
    private String email;


    public Cliente(String CPF, String nome, String email)
    {

        this.CPF = CPF;
        this.nome = nome;
        this.email = email;

    }


    public String getCPF()
    {

        return CPF;

    }


    public String getNome()
    {

        return nome;

    }

    public void setNome(String nome)
    {

        this.nome = nome;

    }


    public String getEmail()
    {

        return email;

    }

    public void setEmail(String email)
    {

        this.email = email;

    }


    public boolean Equals(Object objeto)
    {
        
        if(this == objeto)
        {

            return true;

        }

        if(objeto == null || getClass() != objeto.getClass())
        {

            return false;

        }

        Cliente compara_cliente = (Cliente) objeto;

        return this.CPF != null && this.CPF.equals(compara_cliente.CPF);

    }

    public String toString()
    {

        return String.format("Cliente: " + nome + " | Contato: " + email);

    }

}
