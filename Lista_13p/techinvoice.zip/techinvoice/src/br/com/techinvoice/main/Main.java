package br.com.techinvoice.main;

import br.com.techinvoice.database.GerenciadorConfiguracao;

public class Main {
    
    public static void main(String[] args)
    {
    
        GerenciadorConfiguracao congiguracao_1 = GerenciadorConfiguracao.getInstance();

        

    }

}
